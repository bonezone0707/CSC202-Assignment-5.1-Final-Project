﻿namespace First_Project_C__3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FirstNumber = new Label();
            SecondNumber = new Label();
            btnAdd_Click = new Button();
            btnSubtract_Click = new Button();
            btnMultiply_Click = new Button();
            btnDivide_Click = new Button();
            Result = new Label();
            txtFirstNumber = new TextBox();
            txtSecondNumber = new TextBox();
            ResultOutput = new TextBox();
            btnViewHistory = new Button();
            SuspendLayout();
            // 
            // FirstNumber
            // 
            FirstNumber.AutoSize = true;
            FirstNumber.Location = new Point(148, 88);
            FirstNumber.Name = "FirstNumber";
            FirstNumber.Size = new Size(97, 20);
            FirstNumber.TabIndex = 0;
            FirstNumber.Text = "First Number:";
            // 
            // SecondNumber
            // 
            SecondNumber.AutoSize = true;
            SecondNumber.Location = new Point(148, 156);
            SecondNumber.Name = "SecondNumber";
            SecondNumber.Size = new Size(119, 20);
            SecondNumber.TabIndex = 1;
            SecondNumber.Text = "Second Number:";
            // 
            // btnAdd_Click
            // 
            btnAdd_Click.Location = new Point(148, 212);
            btnAdd_Click.Name = "btnAdd_Click";
            btnAdd_Click.Size = new Size(94, 29);
            btnAdd_Click.TabIndex = 2;
            btnAdd_Click.Text = "+";
            btnAdd_Click.UseVisualStyleBackColor = true;
            btnAdd_Click.Click += Button1_Click;
            // 
            // btnSubtract_Click
            // 
            btnSubtract_Click.Location = new Point(248, 212);
            btnSubtract_Click.Name = "btnSubtract_Click";
            btnSubtract_Click.Size = new Size(94, 29);
            btnSubtract_Click.TabIndex = 3;
            btnSubtract_Click.Text = "-";
            btnSubtract_Click.UseVisualStyleBackColor = true;
            btnSubtract_Click.Click += Button2_Click;
            // 
            // btnMultiply_Click
            // 
            btnMultiply_Click.Location = new Point(357, 212);
            btnMultiply_Click.Name = "btnMultiply_Click";
            btnMultiply_Click.Size = new Size(94, 29);
            btnMultiply_Click.TabIndex = 4;
            btnMultiply_Click.Text = "*";
            btnMultiply_Click.UseVisualStyleBackColor = true;
            btnMultiply_Click.Click += Button3_Click;
            // 
            // btnDivide_Click
            // 
            btnDivide_Click.Location = new Point(466, 212);
            btnDivide_Click.Name = "btnDivide_Click";
            btnDivide_Click.Size = new Size(94, 29);
            btnDivide_Click.TabIndex = 5;
            btnDivide_Click.Text = "/";
            btnDivide_Click.UseVisualStyleBackColor = true;
            btnDivide_Click.Click += Button4_Click;
            // 
            // Result
            // 
            Result.AutoSize = true;
            Result.Location = new Point(148, 316);
            Result.Name = "Result";
            Result.Size = new Size(52, 20);
            Result.TabIndex = 6;
            Result.Text = "Result:";
            // 
            // txtFirstNumber
            // 
            txtFirstNumber.Location = new Point(263, 88);
            txtFirstNumber.Name = "txtFirstNumber";
            txtFirstNumber.Size = new Size(125, 27);
            txtFirstNumber.TabIndex = 7;
            txtFirstNumber.TextChanged += FirstNumberInput_TextChanged;
            // 
            // txtSecondNumber
            // 
            txtSecondNumber.Location = new Point(273, 156);
            txtSecondNumber.Name = "txtSecondNumber";
            txtSecondNumber.Size = new Size(125, 27);
            txtSecondNumber.TabIndex = 8;
            txtSecondNumber.TextChanged += SecondNumberInput_TextChanged;
            // 
            // ResultOutput
            // 
            ResultOutput.Location = new Point(206, 313);
            ResultOutput.Name = "ResultOutput";
            ResultOutput.Size = new Size(202, 27);
            ResultOutput.TabIndex = 9;
            ResultOutput.TextChanged += ResultOutput_TextChanged;
            // 
            // btnViewHistory
            // 
            btnViewHistory.Location = new Point(206, 378);
            btnViewHistory.Name = "btnViewHistory";
            btnViewHistory.Size = new Size(161, 29);
            btnViewHistory.TabIndex = 10;
            btnViewHistory.Text = "View History";
            btnViewHistory.UseVisualStyleBackColor = true;
            btnViewHistory.Click += BtnViewHistory_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Red;
            ClientSize = new Size(845, 490);
            Controls.Add(btnViewHistory);
            Controls.Add(ResultOutput);
            Controls.Add(txtSecondNumber);
            Controls.Add(txtFirstNumber);
            Controls.Add(Result);
            Controls.Add(btnDivide_Click);
            Controls.Add(btnMultiply_Click);
            Controls.Add(btnSubtract_Click);
            Controls.Add(btnAdd_Click);
            Controls.Add(SecondNumber);
            Controls.Add(FirstNumber);
            Name = "Form1";
            Text = "Simple Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label FirstNumber;
        private Label SecondNumber;
        private Button btnAdd_Click;
        private Button btnSubtract_Click;
        private Button btnMultiply_Click;
        private Button btnDivide_Click;
        private Label Result;
        private TextBox txtFirstNumber;
        private TextBox txtSecondNumber;
        private TextBox ResultOutput;
        private Button btnViewHistory;
    }
}
