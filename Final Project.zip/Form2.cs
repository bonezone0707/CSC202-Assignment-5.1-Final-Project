﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Windows.Forms;

// Namespace for the project, grouping related classes together.
namespace First_Project_C__3
{
    // Partial class Form2, inheriting from the Form class for GUI functionality.
    public partial class Form2 : Form
    {
        // Constant string defining the file path where calculation history is stored.
        private const string filePath = "results.txt";

        // Constructor for Form2
        public Form2()
        {
            InitializeComponent(); // Initializes UI components.
            LoadHistory(); // Loads calculation history when the form opens.
        }

        /// <summary>
        /// Reads the calculation history from a file and displays it in the ListBox.
        /// </summary>
        private void LoadHistory()
        {
            try
            {
                // Check if the history file exists.
                if (File.Exists(filePath))
                {
                    // Read all lines from the file.
                    string[] lines = File.ReadAllLines(filePath);

                    // Clear the ListBox before adding new history entries.
                    historyListBox.Items.Clear();

                    // Add history entries to the ListBox.
                    historyListBox.Items.AddRange(lines);
                }
                else
                {
                    // Show a message if no history file is found.
                    MessageBox.Show("No history found.");
                }
            }
            catch (Exception ex)
            {
                // Display an error message in case of an exception.
                MessageBox.Show("Error loading history: " + ex.Message);
            }
        }

        /// <summary>
        /// Initializes components of the form (UI elements).
        /// </summary>
        private void InitializeComponent()
        {
            // Creating the ListBox to display history.
            historyListBox = new ListBox();

            // Creating the "Clear History" button.
            BtnClearHistory = new Button();

            // Suspend layout to optimize performance during UI modifications.
            SuspendLayout();

            // 
            // historyListBox Configuration
            // 
            historyListBox.FormattingEnabled = true;
            historyListBox.Location = new Point(430, 255); // Positioning on the form.
            historyListBox.Name = "historyListBox";
            historyListBox.Size = new Size(396, 204); // Setting size.
            historyListBox.TabIndex = 0; // Tab index for keyboard navigation.
            historyListBox.SelectedIndexChanged += HistoryListBox_SelectedIndexChanged; // Event handler for selection change.

            // 
            // BtnClearHistory Configuration
            // 
            BtnClearHistory.Location = new Point(131, 402); // Positioning on the form.
            BtnClearHistory.Name = "BtnClearHistory";
            BtnClearHistory.Size = new Size(180, 29); // Setting size.
            BtnClearHistory.TabIndex = 1; // Tab index for keyboard navigation.
            BtnClearHistory.Text = "Clear History"; // Button text.
            BtnClearHistory.UseVisualStyleBackColor = true; // Uses default styling.
            BtnClearHistory.Click += BtnClearHistory_Click_1; // Event handler for button click.

            // 
            // Form2 Configuration
            // 
            BackColor = SystemColors.ActiveCaption; // Setting background color.
            ClientSize = new Size(868, 504); // Defining form size.
            Controls.Add(BtnClearHistory); // Adding the button to the form.
            Controls.Add(historyListBox); // Adding the ListBox to the form.
            Name = "Form2"; // Setting form name.

            // Resume layout after adding UI components.
            ResumeLayout(false);
        }

        /// <summary>
        /// Event handler for when the user selects an item in the history ListBox.
        /// Currently, it does nothing but can be extended for further functionality.
        /// </summary>
        private void HistoryListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // This function can be implemented if selection behavior is required.
        }

        /// <summary>
        /// Clears the history from both memory (ListBox) and the file.
        /// </summary>
        private void BtnClearHistory_Click_1(object sender, EventArgs e)
        {
            try
            {
                string filePath = "results.txt"; // Path to the history file.

                // Clear the contents of the history file.
                System.IO.File.WriteAllText(filePath, string.Empty);

                // Clear the ListBox content.
                historyListBox.Items.Clear();

                // Inform the user that history has been cleared.
                MessageBox.Show("History cleared successfully.");
            }
            catch (Exception ex)
            {
                // Display an error message if an exception occurs.
                MessageBox.Show("Error clearing history: " + ex.Message);
            }
        }

        // UI components as private fields of the class.
        private ListBox historyListBox; // ListBox to display history.
        private Button BtnClearHistory; // Button to clear history.
    }
}
