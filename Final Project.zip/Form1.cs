namespace First_Project_C__3
{
    public partial class Form1 : Form
    {
        // Arrays to store the last 10 results and operations performed
        private readonly double[] resultsArray = new double[10];
        private readonly string[] operationsArray = new string[10];
        private int index = 0; // Keeps track of the next available index in the array
        private const string filePath = "results.txt"; // File path to store calculation history
        public Form1()
        {
            InitializeComponent();
        }

        private void FirstNumberInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void SecondNumberInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultOutput_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Validates user input and converts it to numbers.
        /// Uses a retry mechanism to allow up to 3 attempts for valid input.
        /// </summary>
        private bool TryGetInput(out double firstNumber, out double secondNumber)
        {
            firstNumber = 0;
            secondNumber = 0;
            int retryCount = 0;
            const int maxRetries = 3;

            while (retryCount < maxRetries)
            {
                try
                {
                    // Attempt to parse the text fields into numbers
                    if (!double.TryParse(txtFirstNumber.Text, out firstNumber) ||
                        !double.TryParse(txtSecondNumber.Text, out secondNumber))
                    {
                        throw new FormatException("Invalid input. Please enter valid numbers.");
                    }
                    return true;
                }
                catch (FormatException ex)
                {
                    ResultOutput.Text = ex.Message;
                    retryCount++;
                    if (retryCount == maxRetries)
                    {
                        ResultOutput.Text = "Max retries exceeded.";
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Performs the selected arithmetic operation and handles exceptions.
        /// </summary>
        private void PerformOperation(Func<double, double, double> operation, string operationName)
        {
            if (TryGetInput(out double firstNumber, out double secondNumber))
            {
                try
                {
                    // Prevent division by zero
                    if (operationName == "Division" && secondNumber == 0)
                        throw new DivideByZeroException("Cannot divide by zero!");

                    // Execute the operation
                    double result = operation(firstNumber, secondNumber);
                    ResultOutput.Text = $"{operationName} Result: {result}";

                    // Store the result in memory and save it to a file
                    StoreResult($"{operationName}: {firstNumber} and {secondNumber} = {result}");
                }
                catch (DivideByZeroException ex)
                {
                    ResultOutput.Text = ex.Message;
                }
            }
        }

        /// <summary>
        /// Stores the result in an array and writes it to a file.
        /// </summary>
        private void StoreResult(string result)
        {
            if (index < resultsArray.Length)
            {
                // Store result in the arrays
                resultsArray[index] = double.Parse(result.Split('=')[1].Trim());
                operationsArray[index] = result;
                index++;
            }
            else
            {
                // Shift the arrays to make room for new entries
                ShiftArray();
                resultsArray[^1] = double.Parse(result.Split('=')[1].Trim());
                operationsArray[^1] = result;
            }

            try
            {
                // Append the result to a file for persistent history
                File.AppendAllText(filePath, result + Environment.NewLine);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving to file: " + ex.Message);
            }
        }

        /// <summary>
        /// Shifts the array elements left when full, removing the oldest entry.
        /// This maintains only the most recent 10 calculations.
        /// </summary>
        private void ShiftArray()
        {
            for (int i = 1; i < resultsArray.Length; i++)
            {
                resultsArray[i - 1] = resultsArray[i];
                operationsArray[i - 1] = operationsArray[i];
            }
        }

        // Button Click Event Handlers for arithmetic operations
        private void Button1_Click(object sender, EventArgs e) => PerformOperation((a, b) => a + b, "Addition");
        private void Button2_Click(object sender, EventArgs e) => PerformOperation((a, b) => a - b, "Subtraction");
        private void Button3_Click(object sender, EventArgs e) => PerformOperation((a, b) => a * b, "Multiplication");
        private void Button4_Click(object sender, EventArgs e) => PerformOperation((a, b) => a / b, "Division");

        /// <summary>
        /// Opens Form2 to display the calculation history.
        /// </summary>
        private void BtnViewHistory_Click(object sender, EventArgs e)
        {
            Form2 historyForm = new();
            historyForm.Show();
        }
    }
}
