﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First_Project_C__3
{
    partial class CalculatorHistory
    {
    }
        namespace First_Project_C__3
    {
        partial class Form2
        {
            private System.ComponentModel.IContainer components = null;
            private System.Windows.Forms.ListBox historyListBox;
            private System.Windows.Forms.Button btnClearHistory;
            private EventHandler btnClearHistory_Click; 

            public IContainer Components { get => components; set => components = value; }

            private void InitializeComponent()
            {
                this.historyListBox = new System.Windows.Forms.ListBox();
                this.btnClearHistory = new System.Windows.Forms.Button();

                // historyListBox
                this.historyListBox.FormattingEnabled = true;
                this.historyListBox.Location = new System.Drawing.Point(12, 12);
                this.historyListBox.Size = new System.Drawing.Size(260, 200);
                this.historyListBox.TabIndex = 0;

                // btnClearHistory
                this.btnClearHistory.Location = new System.Drawing.Point(90, 220);
                this.btnClearHistory.Size = new System.Drawing.Size(100, 30);
                this.btnClearHistory.Text = "Clear History";
                this.btnClearHistory.UseVisualStyleBackColor = true;
                this.btnClearHistory.Click += new System.EventHandler(this.btnClearHistory_Click);

                
            }
        }
    }
}

